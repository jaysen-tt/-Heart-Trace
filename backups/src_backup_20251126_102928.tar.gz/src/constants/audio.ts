export interface Track {
  id: string;
  title: string;
  category: 'Rain' | 'Sunny' | 'Love' | 'Focus';
  uri: string;
  cover: string; // Image URL or Icon name
}

export const ATMOSPHERE_TRACKS: Track[] = [
  {
    id: 'rain_1',
    title: 'Gentle Rain',
    category: 'Rain',
    // CC0 Rain Sound
    uri: 'https://cdn.pixabay.com/download/audio/2022/03/24/audio_0772a7d279.mp3?filename=rain-and-thunder-16705.mp3', 
    cover: 'rainy-outline' 
  },
  {
    id: 'focus_1',
    title: 'Zen Garden',
    category: 'Focus',
    // CC0 Meditation Bell/Ambient
    uri: 'https://cdn.pixabay.com/download/audio/2022/10/25/audio_d66ce62344.mp3?filename=meditation-bell-sound-114184.mp3',
    cover: 'leaf-outline'
  },
  {
    id: 'sunny_1',
    title: 'Morning Birds',
    category: 'Sunny',
    // CC0 Forest Birds
    uri: 'https://cdn.pixabay.com/download/audio/2021/08/09/audio_04d577675e.mp3?filename=forest-birds-11156.mp3',
    cover: 'sunny-outline'
  },
  {
    id: 'love_1',
    title: 'Sweet Piano',
    category: 'Love',
    // CC0 Piano
    uri: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_7959356d36.mp3?filename=piano-moment-11397.mp3',
    cover: 'heart-outline'
  }
];

