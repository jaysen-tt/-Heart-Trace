export const PALETTE = {
  dark: {
    background: '#0F0F11',
    surface: '#1C1C1E',
    surfaceHighlight: '#2C2C2E',
    text: '#FFFFFF',
    textSecondary: '#8E8E93',
    textTertiary: '#48484A',
    border: 'rgba(255, 255, 255, 0.1)',
    todayIndicator: '#FFFFFF',
    success: '#32D74B',
  },
  light: {
    background: '#F2F2F7',
    surface: '#FFFFFF',
    surfaceHighlight: '#E5E5EA',
    text: '#000000',
    textSecondary: '#8E8E93',
    textTertiary: '#C7C7CC',
    border: 'rgba(0, 0, 0, 0.1)',
    todayIndicator: '#007AFF',
    success: '#34C759',
  }
};

// Default export for backward compatibility during refactor
export const COLORS = PALETTE.dark;

export const MOOD_COLORS = {
    rad: '#FF2D55',
    good: '#FFD60A',
    meh: '#64D2FF',
    bad: '#BF5AF2',
    awful: '#5E5CE6',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const RADIUS = {
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  round: 999,
};

export const FONTS = {
  regular: { fontWeight: '400' as const },
  medium: { fontWeight: '500' as const },
  bold: { fontWeight: '700' as const },
  heavy: { fontWeight: '800' as const },
};
