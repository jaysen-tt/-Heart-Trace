import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { MoodProvider } from '../context/MoodContext';
import { SettingsProvider, useSettings } from '../context/SettingsContext';

function RootLayout() {
  const { theme } = useSettings();
  return (
    <SafeAreaProvider>
      <StatusBar style={theme === 'dark' ? 'light' : 'dark'} />
      <Stack screenOptions={{ headerShown: false }} />
    </SafeAreaProvider>
  );
}

export default function Layout() {
  return (
    <SettingsProvider>
      <MoodProvider>
         <RootLayout />
      </MoodProvider>
    </SettingsProvider>
  );
}
