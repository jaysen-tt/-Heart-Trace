import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { PALETTE } from '../constants/theme';
import { TRANSLATIONS, Language } from '../constants/i18n';
import { Habit, HABITS_LIST } from '../types/mood';

type ThemeMode = 'light' | 'dark';

interface SettingsContextType {
  theme: ThemeMode;
  language: Language;
  name: string;
  avatarUri: string | null;
  birthDate: string | null;
  targetDate: string | null;
  colors: typeof PALETTE.dark;
  activeHabits: Habit[];
  t: (key: keyof typeof TRANSLATIONS.en) => string;
  setTheme: (theme: ThemeMode) => void;
  setLanguage: (lang: Language) => void;
  setName: (name: string) => void;
  setAvatarUri: (uri: string | null) => void;
  setBirthDate: (date: string | null) => void;
  setTargetDate: (date: string | null) => void;
  addHabit: (label: string) => void;
  removeHabit: (id: string) => void;
  reorderHabits: (newOrder: any[]) => void;
}

const SettingsContext = createContext<SettingsContextType>({
  theme: 'dark',
  language: 'en',
  name: '',
  avatarUri: null,
  birthDate: null,
  targetDate: null,
  colors: PALETTE.dark,
  activeHabits: [],
  t: (key) => key,
  setTheme: () => {},
  setLanguage: () => {},
  setName: () => {},
  setAvatarUri: () => {},
  setBirthDate: () => {},
  setTargetDate: () => {},
  addHabit: () => {},
  removeHabit: () => {},
  reorderHabits: () => {},
});

export const useSettings = () => useContext(SettingsContext);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeMode>('dark');
  const [language, setLanguageState] = useState<Language>('en');
  const [name, setNameState] = useState<string>('');
  const [avatarUri, setAvatarUriState] = useState<string | null>(null);
  const [birthDate, setBirthDateState] = useState<string | null>(null);
  const [targetDate, setTargetDateState] = useState<string | null>(null);
  const [activeHabits, setActiveHabits] = useState<Habit[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const savedTheme = await AsyncStorage.getItem('@settings_theme');
      const savedLang = await AsyncStorage.getItem('@settings_lang');
      const savedName = await AsyncStorage.getItem('@settings_name');
      const savedAvatar = await AsyncStorage.getItem('@settings_avatar');
      const savedBirthDate = await AsyncStorage.getItem('@settings_birth_date');
      const savedTargetDate = await AsyncStorage.getItem('@settings_target_date');
      const savedHabits = await AsyncStorage.getItem('@settings_habits');
      
      if (savedTheme) setThemeState(savedTheme as ThemeMode);
      if (savedLang) setLanguageState(savedLang as Language);
      if (savedName) setNameState(savedName);
      if (savedAvatar) setAvatarUriState(savedAvatar);
      if (savedBirthDate) setBirthDateState(savedBirthDate);
      if (savedTargetDate) setTargetDateState(savedTargetDate);
      
      if (savedHabits) {
          setActiveHabits(JSON.parse(savedHabits));
      } else {
          // Default to initial 4 habits for new users, but allow expansion
          setActiveHabits(HABITS_LIST.slice(0, 4)); 
      }

    } catch (e) {
      console.error('Failed to load settings');
    } finally {
      setIsLoaded(true);
    }
  };

  const setTheme = async (newTheme: ThemeMode) => {
    setThemeState(newTheme);
    await AsyncStorage.setItem('@settings_theme', newTheme);
  };

  const setLanguage = async (newLang: Language) => {
    setLanguageState(newLang);
    await AsyncStorage.setItem('@settings_lang', newLang);
  };

  const setName = async (newName: string) => {
    setNameState(newName);
    await AsyncStorage.setItem('@settings_name', newName);
  };

  const setAvatarUri = async (newUri: string | null) => {
    setAvatarUriState(newUri);
    if (newUri) {
      await AsyncStorage.setItem('@settings_avatar', newUri);
    } else {
      await AsyncStorage.removeItem('@settings_avatar');
    }
  };

  const setBirthDate = async (date: string | null) => {
    setBirthDateState(date);
    if (date) {
      await AsyncStorage.setItem('@settings_birth_date', date);
    } else {
      await AsyncStorage.removeItem('@settings_birth_date');
    }
  };

  const setTargetDate = async (date: string | null) => {
    setTargetDateState(date);
    if (date) {
      await AsyncStorage.setItem('@settings_target_date', date);
    } else {
      await AsyncStorage.removeItem('@settings_target_date');
    }
  };

  const addHabit = async (label: string) => {
      const newHabit: Habit = {
          id: `custom_${Date.now()}`,
          label,
          icon: 'star-outline', // Unified icon for custom habits
          isCustom: true
      };
      const updated = [...activeHabits, newHabit];
      setActiveHabits(updated);
      await AsyncStorage.setItem('@settings_habits', JSON.stringify(updated));
  };

  const removeHabit = async (id: string) => {
      const updated = activeHabits.filter(h => h.id !== id);
      setActiveHabits(updated);
      await AsyncStorage.setItem('@settings_habits', JSON.stringify(updated));
  };

  const reorderHabits = async (newOrder: any[]) => {
      setActiveHabits(newOrder);
      await AsyncStorage.setItem('@settings_habits', JSON.stringify(newOrder));
  };

  const t = (key: keyof typeof TRANSLATIONS.en) => {
    return TRANSLATIONS[language][key] || key;
  };

  const colors = PALETTE[theme];

  if (!isLoaded) return null; // Or a loading spinner

  return (
    <SettingsContext.Provider value={{ 
        theme, language, name, avatarUri, birthDate, targetDate, colors, activeHabits, 
        t, setTheme, setLanguage, setName, setAvatarUri, setBirthDate, setTargetDate, addHabit, removeHabit, reorderHabits
    }}>
      {children}
    </SettingsContext.Provider>
  );
};
